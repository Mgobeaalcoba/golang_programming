package pkg

func (t1) fn4() {} //@ used("fn4", true)
