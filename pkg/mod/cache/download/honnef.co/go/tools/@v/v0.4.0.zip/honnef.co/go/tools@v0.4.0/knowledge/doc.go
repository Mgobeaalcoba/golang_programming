// Package knowledge contains manually collected information about Go APIs.
package knowledge
