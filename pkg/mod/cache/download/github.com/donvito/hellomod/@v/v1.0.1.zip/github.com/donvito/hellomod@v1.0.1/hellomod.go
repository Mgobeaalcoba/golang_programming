package hellomod

import (
	"fmt"
)

//SayHello function
func SayHello() {
	fmt.Println("Hello World v1.0.1!!!")
}
