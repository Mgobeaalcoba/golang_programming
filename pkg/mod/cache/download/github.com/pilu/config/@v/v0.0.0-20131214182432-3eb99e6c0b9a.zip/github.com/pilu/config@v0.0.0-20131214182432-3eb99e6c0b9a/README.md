# Config

[![Build Status](https://travis-ci.org/pilu/config.png?branch=master)](https://travis-ci.org/pilu/config)

Configuration file parser for [Go](http://golang.org/).
For documentation and examples check here: [http://godoc.org/github.com/pilu/config](http://godoc.org/github.com/pilu/config)

## Author

Andrea Franz - [http://gravityblast.com](http://gravityblast.com)

## Contributing

1. Fork it
2. Create your feature branch (`git checkout -b my-new-feature`)
3. Commit your changes (`git commit -am 'Add some feature'`)
4. Push to the branch (`git push origin my-new-feature`)
5. Create new Pull Request
